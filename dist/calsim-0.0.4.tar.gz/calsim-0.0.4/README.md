# CalSim
Multi-purpose educational robotics simulator built for the Berkeley courses 106/206 AB.
